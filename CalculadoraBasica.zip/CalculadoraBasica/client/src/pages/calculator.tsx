import { useState, useEffect } from "react";

// Estado de la calculadora
interface CalculatorState {
  currentInput: string;
  previousInput: string | null;
  operator: string | null;
}

// Componente principal de la calculadora
export default function Calculator() {
  const [state, setState] = useState<CalculatorState>({
    currentInput: '0',
    previousInput: null,
    operator: null,
  });

  // Mapeo de operadores a símbolos para la pantalla
  const getOperatorSymbol = (op: string | null): string => {
    switch(op) {
      case '+': return '+';
      case '-': return '−';
      case '*': return '×';
      case '/': return '÷';
      default: return '';
    }
  };
  
  // Función para manejar la entrada de números
  const handleNumber = (num: string) => {
    setState(prevState => {
      // Si el input actual es '0' o si hay un resultado pendiente, reemplazarlo.
      if (prevState.currentInput === '0' || prevState.operator && prevState.previousInput === prevState.currentInput) {
        return { ...prevState, currentInput: num };
      }
      // Evitar múltiples puntos decimales
      if (num === '.' && prevState.currentInput.includes('.')) {
        return prevState;
      }
      return { ...prevState, currentInput: prevState.currentInput + num };
    });
  };

  // Función para manejar la entrada de operadores
  const handleOperator = (op: string) => {
    setState(prevState => {
      // Si ya hay una operación pendiente, la resuelve primero
      if (prevState.operator && prevState.previousInput !== null) {
        const result = calculate(prevState);
        return {
          previousInput: result,
          currentInput: result,
          operator: op,
        };
      }
      // Guarda el estado actual para la siguiente operación
      return { 
        ...prevState, 
        previousInput: prevState.currentInput,
        operator: op,
      };
    });
  };
  
  // Realiza el cálculo final
  const handleEquals = () => {
    if (!state.operator || state.previousInput === null) return;
    
    const result = calculate(state);
    setState({
      currentInput: result,
      previousInput: null,
      operator: null,
    });
  };

  // Lógica de cálculo central
  const calculate = (calcState: CalculatorState): string => {
    const prev = parseFloat(calcState.previousInput!);
    const current = parseFloat(calcState.currentInput);
    let result = 0;

    switch(calcState.operator) {
      case '+': result = prev + current; break;
      case '-': result = prev - current; break;
      case '*': result = prev * current; break;
      case '/': 
        if (current === 0) return 'Error';
        result = prev / current;
        break;
      default: return calcState.currentInput;
    }
    // Formateo para evitar decimales largos
    return String(parseFloat(result.toPrecision(12)));
  };

  // Limpia toda la memoria
  const clearAll = () => {
    setState({
      currentInput: '0',
      previousInput: null,
      operator: null,
    });
  };

  // Borra el último dígito
  const backspace = () => {
    setState(prevState => ({
      ...prevState,
      currentInput: prevState.currentInput.length > 1 ? prevState.currentInput.slice(0, -1) : '0',
    }));
  };
  
  // Soporte para teclado físico
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const { key } = event;
      if (key >= '0' && key <= '9' || key === '.') handleNumber(key);
      if (key === '+' || key === '-' || key === '*' || key === '/') handleOperator(key);
      if (key === 'Enter' || key === '=') handleEquals();
      if (key === 'Escape') clearAll();
      if (key === 'Backspace') backspace();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [state]); // Dependencia para que use el estado actualizado


  const Button = ({ children, onClick, className = "", type = "number" }) => {
    const baseClasses = "button-3d rounded-xl h-14 font-orbitron font-bold text-lg";
    const typeClasses = {
      number: "number-btn",
      operator: "operator-btn",
      special: "special-btn"
    };
    return <button className={`${baseClasses} ${typeClasses[type]} ${className}`} onClick={onClick}>{children}</button>;
  };

  return (
    <div className="min-h-screen bg-dark-bg geometric-bg flex items-center justify-center p-4 font-inter">
      <div className="glass-morphism rounded-3xl p-8 shadow-2xl max-w-md w-full">
        
        <div className="text-center mb-6">
          <h1 className="text-2xl font-orbitron font-bold text-cyan-400">NeonCalc</h1>
          <p className="text-gray-400 text-sm mt-1">v1.0</p>
        </div>
        
        <div className="lcd-display rounded-2xl p-6 mb-6">
          <div className="text-right">
            <div className="text-cyan-400 text-sm font-orbitron opacity-60 h-5">
              {state.previousInput} {getOperatorSymbol(state.operator)}
            </div>
            <div className="text-cyan-400 text-4xl font-orbitron font-bold neon-text mt-2 break-all">
              {state.currentInput}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-3">
          <Button type="special" onClick={clearAll}>AC</Button>
          <Button type="special" onClick={backspace}>⌫</Button>
          <Button type="operator" onClick={() => handleOperator('/')}>÷</Button>
          <Button type="operator" onClick={() => handleOperator('*')}>×</Button>
          
          <Button onClick={() => handleNumber('7')}>7</Button>
          <Button onClick={() => handleNumber('8')}>8</Button>
          <Button onClick={() => handleNumber('9')}>9</Button>
          <Button type="operator" onClick={() => handleOperator('-')}>−</Button>
          
          <Button onClick={() => handleNumber('4')}>4</Button>
          <Button onClick={() => handleNumber('5')}>5</Button>
          <Button onClick={() => handleNumber('6')}>6</Button>
          <Button type="operator" onClick={() => handleOperator('+')}>+</Button>
          
          <Button className="col-span-2" onClick={() => handleNumber('0')}>0</Button>
          <Button onClick={() => handleNumber('.')}>.</Button>
          <Button type="special" onClick={handleEquals}>=</Button>
        </div>
        
        <div className="text-center mt-6">
          <p className="text-gray-500 text-xs font-light">Simple React Calculator</p>
        </div>
        
      </div>
    </div>
  );
}